package com.greninja.mod;

import com.greninja.mod.hud.ArmorHudRenderer;
import com.greninja.mod.hud.ShieldHudOverlay;
import com.greninja.mod.network.NetworkOptimizer;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class GreninjaClient implements ClientModInitializer {
    public static final String MOD_ID = "greninja";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitializeClient() {
        LOGGER.info("[Greninja] Loading...");
        ShieldHudOverlay.register();
        HudRenderCallback.EVENT.register(new ArmorHudRenderer());
        ClientTickEvents.END_CLIENT_TICK.register(client -> NetworkOptimizer.onTick(client));
        LOGGER.info("[Greninja] All features loaded!");
    }
}
