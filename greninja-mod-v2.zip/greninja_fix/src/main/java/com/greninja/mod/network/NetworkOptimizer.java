package com.greninja.mod.network;

import com.greninja.mod.GreninjaClient;
import net.minecraft.client.MinecraftClient;

public class NetworkOptimizer {
    private static int tickCount = 0;
    private static long lastPingCheck = 0;
    private static int chunkRequestCooldown = 0;

    public static void onTick(MinecraftClient mc) {
        tickCount++;
        if (chunkRequestCooldown > 0) chunkRequestCooldown--;
        if (tickCount % 20 == 0) checkConnectionQuality(mc);
    }

    private static void checkConnectionQuality(MinecraftClient mc) {
        if (mc.getNetworkHandler() == null) return;
        long now = System.currentTimeMillis();
        if (now - lastPingCheck > 10000) {
            lastPingCheck = now;
            GreninjaClient.LOGGER.debug("[Greninja] Network tick OK.");
        }
    }

    public static boolean shouldSendChunkRequest() {
        if (chunkRequestCooldown <= 0) {
            chunkRequestCooldown = 3;
            return true;
        }
        return false;
    }
}
