package com.greninja.mod.hud;

import com.greninja.mod.mixin.ShieldIndicatorMixin;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.util.UseAction;
import net.minecraft.util.math.Box;

public class ShieldHudOverlay {
    private static final float YELLOW_R = 1.0f, YELLOW_G = 1.0f, YELLOW_B = 0.0f, YELLOW_A = 1.0f;
    private static final float RED_R = 1.0f, RED_G = 0.05f, RED_B = 0.05f, RED_A = 1.0f;
    private static final double EXPAND = 0.05;

    public static void register() {
        WorldRenderEvents.AFTER_ENTITIES.register(ShieldHudOverlay::render);
    }

    private static void render(WorldRenderContext context) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.world == null || mc.player == null) return;

        MatrixStack matrices = context.matrixStack();
        if (matrices == null) return;

        VertexConsumerProvider.Immediate vcp = mc.getBufferBuilders().getEntityVertexConsumers();

        var cam = mc.gameRenderer.getCamera().getPos();
        double camX = cam.x, camY = cam.y, camZ = cam.z;

        for (Entity entity : mc.world.getEntities()) {
            if (!(entity instanceof PlayerEntity player)) continue;
            if (player == mc.player) continue;

            boolean isBlocking = isActivelyBlocking(player);
            boolean isDisabled = ShieldIndicatorMixin.SHIELD_DISABLED_MAP.containsKey(player.getId());
            if (!isBlocking && !isDisabled) continue;

            float r, g, b, a;
            if (isDisabled) { r = RED_R; g = RED_G; b = RED_B; a = RED_A; }
            else { r = YELLOW_R; g = YELLOW_G; b = YELLOW_B; a = YELLOW_A; }

            Box box = player.getBoundingBox().expand(EXPAND);
            matrices.push();
            matrices.translate(box.minX - camX, box.minY - camY, box.minZ - camZ);

            double w = box.maxX - box.minX;
            double h = box.maxY - box.minY;
            double d = box.maxZ - box.minZ;

            VertexConsumer lines = vcp.getBuffer(RenderLayer.getLines());
            drawBox(matrices, lines, 0, 0, 0, w, h, d, r, g, b, a);
            matrices.pop();
        }
        vcp.draw(RenderLayer.getLines());
    }

    private static boolean isActivelyBlocking(PlayerEntity player) {
        if (!player.isUsingItem()) return false;
        var item = player.getActiveItem();
        return item.getItem() == Items.SHIELD && item.getUseAction() == UseAction.BLOCK;
    }

    private static void drawBox(MatrixStack matrices, VertexConsumer lines,
            double x1, double y1, double z1, double x2, double y2, double z2,
            float r, float g, float b, float a) {
        line(matrices, lines, x1,y1,z1, x2,y1,z1, r,g,b,a);
        line(matrices, lines, x2,y1,z1, x2,y1,z2, r,g,b,a);
        line(matrices, lines, x2,y1,z2, x1,y1,z2, r,g,b,a);
        line(matrices, lines, x1,y1,z2, x1,y1,z1, r,g,b,a);
        line(matrices, lines, x1,y2,z1, x2,y2,z1, r,g,b,a);
        line(matrices, lines, x2,y2,z1, x2,y2,z2, r,g,b,a);
        line(matrices, lines, x2,y2,z2, x1,y2,z2, r,g,b,a);
        line(matrices, lines, x1,y2,z2, x1,y2,z1, r,g,b,a);
        line(matrices, lines, x1,y1,z1, x1,y2,z1, r,g,b,a);
        line(matrices, lines, x2,y1,z1, x2,y2,z1, r,g,b,a);
        line(matrices, lines, x2,y1,z2, x2,y2,z2, r,g,b,a);
        line(matrices, lines, x1,y1,z2, x1,y2,z2, r,g,b,a);
    }

    private static void line(MatrixStack matrices, VertexConsumer lines,
            double x1, double y1, double z1, double x2, double y2, double z2,
            float r, float g, float b, float a) {
        float dx = (float)(x2-x1), dy = (float)(y2-y1), dz = (float)(z2-z1);
        float len = (float)Math.sqrt(dx*dx+dy*dy+dz*dz);
        if (len == 0) return;
        dx/=len; dy/=len; dz/=len;
        var entry = matrices.peek();
        lines.vertex(entry, (float)x1,(float)y1,(float)z1).color(r,g,b,a).normal(entry,dx,dy,dz);
        lines.vertex(entry, (float)x2,(float)y2,(float)z2).color(r,g,b,a).normal(entry,dx,dy,dz);
    }
}
