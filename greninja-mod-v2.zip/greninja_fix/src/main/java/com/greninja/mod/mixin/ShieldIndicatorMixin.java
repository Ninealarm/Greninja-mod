package com.greninja.mod.mixin;

import net.minecraft.client.gui.hud.InGameHud;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.util.UseAction;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(InGameHud.class)
public class ShieldIndicatorMixin {
    public static final java.util.concurrent.ConcurrentHashMap<Integer, Integer>
        SHIELD_DISABLED_MAP = new java.util.concurrent.ConcurrentHashMap<>();

    public static void tickShieldDisabledMap() {
        SHIELD_DISABLED_MAP.entrySet().removeIf(e -> {
            e.setValue(e.getValue() - 1);
            return e.getValue() <= 0;
        });
    }

    public static void markShieldDisabled(int entityId) {
        SHIELD_DISABLED_MAP.put(entityId, 100);
    }

    public static boolean isBlockingWithShield(PlayerEntity player) {
        var active = player.getActiveItem();
        if (active.isEmpty()) return false;
        return player.isUsingItem()
            && active.getItem() == Items.SHIELD
            && active.getUseAction() == UseAction.BLOCK;
    }
}
