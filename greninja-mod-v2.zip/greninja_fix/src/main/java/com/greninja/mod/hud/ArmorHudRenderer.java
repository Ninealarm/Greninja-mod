package com.greninja.mod.hud;

import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;

public class ArmorHudRenderer implements HudRenderCallback {
    private static final int PADDING_X = 2;
    private static final int PADDING_Y_FROM_BOTTOM = 60;
    private static final int SLOT_SIZE = 16;
    private static final int SLOT_GAP = 2;
    private static final int BAR_WIDTH = 16;
    private static final int BAR_HEIGHT = 2;

    @Override
    public void onHudRender(DrawContext context, RenderTickCounter tickCounter) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null) return;
        if (mc.options.hudHidden) return;

        PlayerEntity player = mc.player;
        int screenHeight = mc.getWindow().getScaledHeight();

        EquipmentSlot[] slots = {
            EquipmentSlot.FEET, EquipmentSlot.LEGS,
            EquipmentSlot.CHEST, EquipmentSlot.HEAD
        };

        for (int i = 0; i < slots.length; i++) {
            ItemStack stack = player.getEquippedStack(slots[i]);
            if (stack.isEmpty()) continue;

            int x = PADDING_X;
            int y = screenHeight - PADDING_Y_FROM_BOTTOM
                    - (i * (SLOT_SIZE + BAR_HEIGHT + SLOT_GAP + 2));

            context.drawItem(stack, x, y);

            if (stack.isDamageable()) {
                int maxDur = stack.getMaxDamage();
                int curDur = maxDur - stack.getDamage();
                float fraction = (float) curDur / maxDur;

                context.fill(x, y + SLOT_SIZE + 1,
                        x + BAR_WIDTH, y + SLOT_SIZE + 1 + BAR_HEIGHT, 0xFF333333);

                int barColor = getDurabilityColor(fraction);
                int filledWidth = Math.max(1, (int)(fraction * BAR_WIDTH));
                context.fill(x, y + SLOT_SIZE + 1,
                        x + filledWidth, y + SLOT_SIZE + 1 + BAR_HEIGHT, barColor);

                context.drawText(mc.textRenderer, String.valueOf(curDur),
                        x + SLOT_SIZE + 2, y + SLOT_SIZE - 2, barColor, true);
            }
        }
    }

    private static int getDurabilityColor(float fraction) {
        if (fraction > 0.6f) return 0xFF55FF55;
        else if (fraction > 0.3f) return 0xFFFFFF55;
        else return 0xFFFF5555;
    }
}
