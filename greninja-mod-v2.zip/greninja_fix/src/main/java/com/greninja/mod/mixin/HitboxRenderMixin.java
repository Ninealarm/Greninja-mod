package com.greninja.mod.mixin;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.EntityRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.math.Box;
import net.minecraft.client.render.RenderLayer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(EntityRenderer.class)
public class HitboxRenderMixin<T extends Entity> {
    private static final double ATTACK_RANGE = 3.5;

    @Inject(method = "renderLabelIfPresent", at = @At("HEAD"))
    private void greninja$colorHitbox(T entity, Text displayName,
            MatrixStack matrices, VertexConsumerProvider vertexConsumers,
            int light, float tickDelta, CallbackInfo ci) {

        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.world == null || mc.player == null) return;
        if (!(entity instanceof PlayerEntity target)) return;
        if (entity == mc.player) return;
        if (!mc.getEntityRenderDispatcher().shouldRenderHitboxes()) return;

        double distance = mc.player.distanceTo(target);
        boolean inRange = distance <= ATTACK_RANGE;

        float r = inRange ? 1.0f : 1.0f;
        float g = inRange ? 0.05f : 1.0f;
        float b = inRange ? 0.05f : 1.0f;
        float a = inRange ? 1.0f : 0.35f;

        Box box = entity.getBoundingBox();
        double x = entity.getX(), y = entity.getY(), z = entity.getZ();

        double minX = box.minX - x, minY = box.minY - y, minZ = box.minZ - z;
        double maxX = box.maxX - x, maxY = box.maxY - y, maxZ = box.maxZ - z;

        VertexConsumer lines = vertexConsumers.getBuffer(RenderLayer.getLines());
        greninja$drawBox(matrices, lines, minX, minY, minZ, maxX, maxY, maxZ, r, g, b, a);
    }

    private static void greninja$drawBox(MatrixStack matrices, VertexConsumer lines,
            double x1, double y1, double z1, double x2, double y2, double z2,
            float r, float g, float b, float a) {
        greninja$line(matrices, lines, x1,y1,z1, x2,y1,z1, r,g,b,a);
        greninja$line(matrices, lines, x2,y1,z1, x2,y1,z2, r,g,b,a);
        greninja$line(matrices, lines, x2,y1,z2, x1,y1,z2, r,g,b,a);
        greninja$line(matrices, lines, x1,y1,z2, x1,y1,z1, r,g,b,a);
        greninja$line(matrices, lines, x1,y2,z1, x2,y2,z1, r,g,b,a);
        greninja$line(matrices, lines, x2,y2,z1, x2,y2,z2, r,g,b,a);
        greninja$line(matrices, lines, x2,y2,z2, x1,y2,z2, r,g,b,a);
        greninja$line(matrices, lines, x1,y2,z2, x1,y2,z1, r,g,b,a);
        greninja$line(matrices, lines, x1,y1,z1, x1,y2,z1, r,g,b,a);
        greninja$line(matrices, lines, x2,y1,z1, x2,y2,z1, r,g,b,a);
        greninja$line(matrices, lines, x2,y1,z2, x2,y2,z2, r,g,b,a);
        greninja$line(matrices, lines, x1,y1,z2, x1,y2,z2, r,g,b,a);
    }

    private static void greninja$line(MatrixStack matrices, VertexConsumer lines,
            double x1, double y1, double z1, double x2, double y2, double z2,
            float r, float g, float b, float a) {
        float dx = (float)(x2-x1), dy = (float)(y2-y1), dz = (float)(z2-z1);
        float len = (float)Math.sqrt(dx*dx+dy*dy+dz*dz);
        if (len == 0) return;
        dx/=len; dy/=len; dz/=len;
        var entry = matrices.peek();
        lines.vertex(entry, (float)x1,(float)y1,(float)z1).color(r,g,b,a).normal(entry,dx,dy,dz);
        lines.vertex(entry, (float)x2,(float)y2,(float)z2).color(r,g,b,a).normal(entry,dx,dy,dz);
    }
}
