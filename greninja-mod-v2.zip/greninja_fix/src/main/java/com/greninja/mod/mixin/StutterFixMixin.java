package com.greninja.mod.mixin;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(MinecraftClient.class)
public class StutterFixMixin {
    private static final int GC_INTERVAL_TICKS = 600;
    private int greninja$tickCounter = 0;
    private final java.util.HashMap<Integer, Boolean> greninja$shieldWasBlocking = new java.util.HashMap<>();

    @Inject(method = "tick", at = @At("HEAD"))
    private void greninja$onTick(CallbackInfo ci) {
        MinecraftClient mc = (MinecraftClient)(Object)this;
        greninja$tickCounter++;

        if (greninja$tickCounter % GC_INTERVAL_TICKS == 0) {
            System.gc();
        }

        ShieldIndicatorMixin.tickShieldDisabledMap();

        ClientWorld world = mc.world;
        if (world != null && mc.player != null) {
            for (Entity entity : world.getEntities()) {
                if (!(entity instanceof PlayerEntity player)) continue;
                if (player == mc.player) continue;

                int id = player.getId();
                boolean holdingShield = player.getMainHandStack().getItem() == Items.SHIELD
                    || player.getOffHandStack().getItem() == Items.SHIELD;
                boolean wasBlocking = greninja$shieldWasBlocking.getOrDefault(id, false);
                boolean isBlocking = player.isUsingItem() && holdingShield;

                if (wasBlocking && !isBlocking) {
                    float cooldown = mc.player.getItemCooldownManager()
                        .getCooldownProgress(player.getMainHandStack(), 0f);
                    if (cooldown > 0f) {
                        ShieldIndicatorMixin.markShieldDisabled(id);
                    }
                }
                greninja$shieldWasBlocking.put(id, isBlocking);
            }
            greninja$shieldWasBlocking.entrySet()
                .removeIf(e -> world.getEntityById(e.getKey()) == null);
        }
    }
}
