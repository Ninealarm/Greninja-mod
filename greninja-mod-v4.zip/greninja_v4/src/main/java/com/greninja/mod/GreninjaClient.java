package com.greninja.mod;

import com.greninja.mod.hud.GreninjaHudRenderer;
import com.greninja.mod.network.NetworkOptimizer;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class GreninjaClient implements ClientModInitializer {
    public static final String MOD_ID = "greninja";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitializeClient() {
        LOGGER.info("[Greninja] Loaded for 1.21.11");
        HudRenderCallback.EVENT.register(new GreninjaHudRenderer());
        ClientTickEvents.END_CLIENT_TICK.register(NetworkOptimizer::onTick);
    }
}
