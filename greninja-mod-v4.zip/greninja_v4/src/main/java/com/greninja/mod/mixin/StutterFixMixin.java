package com.greninja.mod.mixin;

import net.minecraft.client.Minecraft;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Minecraft.class)
public class StutterFixMixin {
    private int greninja$tickCount = 0;

    @Inject(method = "tick", at = @At("HEAD"))
    private void greninja$onTick(CallbackInfo ci) {
        greninja$tickCount++;
        // Staggered GC every 30 seconds to prevent random freeze spikes
        if (greninja$tickCount % 600 == 0) {
            System.gc();
        }
    }
}
