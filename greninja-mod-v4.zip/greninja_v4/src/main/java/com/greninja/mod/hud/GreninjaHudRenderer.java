package com.greninja.mod.hud;

import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

import java.util.ArrayList;
import java.util.List;

public class GreninjaHudRenderer implements HudRenderCallback {

    // ── Layout constants ──────────────────────────────────────────────────
    private static final int ARMOR_X      = 2;
    private static final int ARMOR_Y_BASE = 60;   // pixels from bottom
    private static final int ITEM_SIZE    = 16;
    private static final int BAR_W        = 16;
    private static final int BAR_H        = 2;
    private static final int ROW_H        = ITEM_SIZE + BAR_H + 4;

    private static final double PVP_RANGE  = 10.0; // blocks — alert range
    private static final double CRIT_RANGE = 3.5;  // blocks — in-attack range

    // ── Colours (ARGB) ────────────────────────────────────────────────────
    private static final int COL_GREEN  = 0xFF55FF55;
    private static final int COL_YELLOW = 0xFFFFFF55;
    private static final int COL_RED    = 0xFFFF4444;
    private static final int COL_ORANGE = 0xFFFF8800;
    private static final int COL_WHITE  = 0xFFFFFFFF;
    private static final int COL_SHADOW = 0xAA000000;
    private static final int COL_BG     = 0x88000000;

    @Override
    public void onHudRender(GuiGraphics g, DeltaTracker delta) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null) return;
        if (mc.options.hideGui) return;

        int sw = mc.getWindow().getGuiScaledWidth();
        int sh = mc.getWindow().getGuiScaledHeight();

        renderArmorHud(g, mc, sh);
        renderPvpHud(g, mc, sw, sh);
    }

    // ══════════════════════════════════════════════════════════════════════
    // 1. ARMOR HUD  (bottom-left, 4 slots with durability bars)
    // ══════════════════════════════════════════════════════════════════════
    private void renderArmorHud(GuiGraphics g, Minecraft mc, int sh) {
        Player player = mc.player;
        EquipmentSlot[] slots = {
            EquipmentSlot.FEET, EquipmentSlot.LEGS,
            EquipmentSlot.CHEST, EquipmentSlot.HEAD
        };

        for (int i = 0; i < slots.length; i++) {
            ItemStack stack = player.getItemBySlot(slots[i]);
            if (stack.isEmpty()) continue;

            int x = ARMOR_X;
            int y = sh - ARMOR_Y_BASE - (i * ROW_H);

            // Item icon
            g.renderItem(stack, x, y);

            // Durability bar
            if (stack.isDamageableItem()) {
                int max  = stack.getMaxDamage();
                int cur  = max - stack.getDamageValue();
                float f  = (float) cur / max;
                int col  = durColor(f);
                int fill = Math.max(1, (int)(f * BAR_W));
                int barY = y + ITEM_SIZE + 1;

                g.fill(x, barY, x + BAR_W, barY + BAR_H, 0xFF333333);
                g.fill(x, barY, x + fill,  barY + BAR_H, col);

                // Durability number (compact)
                String txt = cur >= 1000 ? (cur/1000) + "k" : String.valueOf(cur);
                g.drawString(mc.font, txt, x + ITEM_SIZE + 2, y + ITEM_SIZE - 7, col, true);
            }
        }

        // Held-item durability (main hand) in same style
        ItemStack held = player.getMainHandItem();
        if (!held.isEmpty() && held.isDamageableItem()) {
            int x = ARMOR_X;
            int y = sh - ARMOR_Y_BASE - (slots.length * ROW_H) - 4;
            g.renderItem(held, x, y);
            int max  = held.getMaxDamage();
            int cur  = max - held.getDamageValue();
            float f  = (float) cur / max;
            int col  = durColor(f);
            int fill = Math.max(1, (int)(f * BAR_W));
            int barY = y + ITEM_SIZE + 1;
            g.fill(x, barY, x + BAR_W, barY + BAR_H, 0xFF333333);
            g.fill(x, barY, x + fill,  barY + BAR_H, col);
        }
    }

    // ══════════════════════════════════════════════════════════════════════
    // 2. PVP HUD  (top-right: nearby players + their shield status)
    // ══════════════════════════════════════════════════════════════════════
    private void renderPvpHud(GuiGraphics g, Minecraft mc, int sw, int sh) {
        Player self = mc.player;
        List<Player> nearby = new ArrayList<>();

        for (Player p : mc.level.players()) {
            if (p == self) continue;
            if (self.distanceTo(p) <= PVP_RANGE) nearby.add(p);
        }

        if (nearby.isEmpty()) return;

        int panelW = 130;
        int panelX = sw - panelW - 4;
        int panelY = 4;
        int lineH  = 10;
        int panelH = 12 + nearby.size() * lineH;

        // Semi-transparent background
        g.fill(panelX - 2, panelY - 2, panelX + panelW, panelY + panelH, COL_BG);

        // Header
        g.drawString(mc.font, "§eNearby Players", panelX, panelY, COL_WHITE, false);
        panelY += 11;

        for (Player p : nearby) {
            double dist = self.distanceTo(p);
            boolean inCritRange  = dist <= CRIT_RANGE;
            boolean isBlocking   = isShieldBlocking(p);
            boolean hasShield    = hasShieldEquipped(p);

            // Name color: red if in crit range, yellow if nearby, white otherwise
            int nameCol = inCritRange ? COL_RED : (dist <= 6.0 ? COL_ORANGE : COL_YELLOW);

            String name = p.getName().getString();
            if (name.length() > 10) name = name.substring(0, 9) + "…";

            // Distance
            String distStr = String.format("%.1fm", dist);

            // Shield status
            String shieldStr;
            int shieldCol;
            if (isBlocking) {
                shieldStr = "§a[SHIELD]";
                shieldCol = COL_YELLOW;  // blocking = warn: can't crit
            } else if (hasShield) {
                shieldStr = "§c[OPEN]";
                shieldCol = COL_GREEN;   // has shield but not blocking = good to hit
            } else {
                shieldStr = "";
                shieldCol = COL_WHITE;
            }

            // Render line
            g.drawString(mc.font, name,     panelX,           panelY, nameCol, true);
            g.drawString(mc.font, distStr,  panelX + 72,      panelY, nameCol, true);
            if (!shieldStr.isEmpty()) {
                g.drawString(mc.font, shieldStr, panelX + 96, panelY, shieldCol, true);
            }

            // In-crit-range warning flash (render a small red dot)
            if (inCritRange) {
                g.fill(panelX - 2, panelY, panelX - 1, panelY + 8, COL_RED);
            }

            panelY += lineH;
        }
    }

    // ══════════════════════════════════════════════════════════════════════
    // Helpers
    // ══════════════════════════════════════════════════════════════════════
    private static int durColor(float f) {
        if (f > 0.6f) return COL_GREEN;
        if (f > 0.3f) return COL_YELLOW;
        return COL_RED;
    }

    private static boolean isShieldBlocking(Player p) {
        if (!p.isUsingItem()) return false;
        ItemStack active = p.getUseItem();
        return active.getItem() == Items.SHIELD;
    }

    private static boolean hasShieldEquipped(Player p) {
        return p.getMainHandItem().getItem() == Items.SHIELD
            || p.getOffhandItem().getItem()  == Items.SHIELD;
    }
}
