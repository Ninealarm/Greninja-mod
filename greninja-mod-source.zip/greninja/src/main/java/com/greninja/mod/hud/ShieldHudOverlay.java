package com.greninja.mod.hud;

import com.greninja.mod.mixin.ShieldIndicatorMixin;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.UseAnim;
import net.minecraft.world.phys.AABB;

/**
 * Greninja - Shield Visual Indicator
 *
 * Renders colored outlines around players who are holding shields:
 *   NEON YELLOW = player is actively blocking with shield
 *   NEON RED    = player's shield was just disabled by an axe (lasts 5 seconds)
 *
 * No extra mods required — this is fully self-contained.
 */
public class ShieldHudOverlay {

    // Neon yellow (shield active)
    private static final float YELLOW_R = 1.0f;
    private static final float YELLOW_G = 1.0f;
    private static final float YELLOW_B = 0.0f;
    private static final float YELLOW_A = 1.0f;

    // Neon red (shield disabled)
    private static final float RED_R = 1.0f;
    private static final float RED_G = 0.05f;
    private static final float RED_B = 0.05f;
    private static final float RED_A = 1.0f;

    // Slight expand so the outline is outside the hitbox
    private static final double EXPAND = 0.05;

    public static void register() {
        WorldRenderEvents.AFTER_ENTITIES.register(ShieldHudOverlay::render);
    }

    private static void render(WorldRenderContext context) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.player == null) return;

        PoseStack poseStack = context.matrixStack();
        if (poseStack == null) return;

        MultiBufferSource.BufferSource bufferSource =
            mc.renderBuffers().bufferSource();

        // Camera position for rendering offset
        double camX = mc.gameRenderer.getMainCamera().getPosition().x;
        double camY = mc.gameRenderer.getMainCamera().getPosition().y;
        double camZ = mc.gameRenderer.getMainCamera().getPosition().z;

        for (Entity entity : mc.level.entitiesForRendering()) {
            if (!(entity instanceof Player player)) continue;
            if (player == mc.player) continue;

            boolean isBlocking = isActivelyBlocking(player);
            boolean isDisabled = ShieldIndicatorMixin.SHIELD_DISABLED_MAP.containsKey(player.getId());

            if (!isBlocking && !isDisabled) continue;

            // Choose color: disabled overrides blocking
            float r, g, b, a;
            if (isDisabled) {
                r = RED_R; g = RED_G; b = RED_B; a = RED_A;
            } else {
                r = YELLOW_R; g = YELLOW_G; b = YELLOW_B; a = YELLOW_A;
            }

            AABB box = player.getBoundingBox().inflate(EXPAND);

            poseStack.pushPose();
            poseStack.translate(
                box.minX - camX,
                box.minY - camY,
                box.minZ - camZ
            );

            double w = box.maxX - box.minX;
            double h = box.maxY - box.minY;
            double d = box.maxZ - box.minZ;

            VertexConsumer lines = bufferSource.getBuffer(RenderType.lines());
            drawOutlineBox(poseStack, lines, 0, 0, 0, w, h, d, r, g, b, a);

            poseStack.popPose();
        }

        bufferSource.endBatch(RenderType.lines());
    }

    private static boolean isActivelyBlocking(Player player) {
        if (!player.isUsingItem()) return false;
        var item = player.getUseItem();
        return item.getItem() == Items.SHIELD && item.getUseAnimation() == UseAnim.BLOCK;
    }

    private static void drawOutlineBox(
        PoseStack poseStack, VertexConsumer lines,
        double x1, double y1, double z1,
        double x2, double y2, double z2,
        float r, float g, float b, float a
    ) {
        // Bottom
        line(poseStack, lines, x1, y1, z1, x2, y1, z1, r, g, b, a);
        line(poseStack, lines, x2, y1, z1, x2, y1, z2, r, g, b, a);
        line(poseStack, lines, x2, y1, z2, x1, y1, z2, r, g, b, a);
        line(poseStack, lines, x1, y1, z2, x1, y1, z1, r, g, b, a);
        // Top
        line(poseStack, lines, x1, y2, z1, x2, y2, z1, r, g, b, a);
        line(poseStack, lines, x2, y2, z1, x2, y2, z2, r, g, b, a);
        line(poseStack, lines, x2, y2, z2, x1, y2, z2, r, g, b, a);
        line(poseStack, lines, x1, y2, z2, x1, y2, z1, r, g, b, a);
        // Verticals
        line(poseStack, lines, x1, y1, z1, x1, y2, z1, r, g, b, a);
        line(poseStack, lines, x2, y1, z1, x2, y2, z1, r, g, b, a);
        line(poseStack, lines, x2, y1, z2, x2, y2, z2, r, g, b, a);
        line(poseStack, lines, x1, y1, z2, x1, y2, z2, r, g, b, a);
    }

    private static void line(
        PoseStack poseStack, VertexConsumer lines,
        double x1, double y1, double z1,
        double x2, double y2, double z2,
        float r, float g, float b, float a
    ) {
        float dx = (float)(x2 - x1);
        float dy = (float)(y2 - y1);
        float dz = (float)(z2 - z1);
        float len = (float) Math.sqrt(dx*dx + dy*dy + dz*dz);
        if (len == 0) return;
        dx /= len; dy /= len; dz /= len;

        PoseStack.Pose pose = poseStack.last();
        lines.addVertex(pose, (float)x1, (float)y1, (float)z1)
             .setColor(r, g, b, a)
             .setNormal(pose, dx, dy, dz);
        lines.addVertex(pose, (float)x2, (float)y2, (float)z2)
             .setColor(r, g, b, a)
             .setNormal(pose, dx, dy, dz);
    }
}
