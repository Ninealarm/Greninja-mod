package com.greninja.mod.mixin;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.AABB;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Greninja - PvP Hitbox Color Feature
 *
 * When hitboxes are enabled (F3+B), player hitboxes turn NEON RED
 * when within melee attack range (~3.5 blocks) of the local player.
 * Otherwise they remain the default white/grey color.
 */
@Mixin(EntityRenderer.class)
public class HitboxRenderMixin<T extends Entity> {

    // Attack range (vanilla melee is ~3.0, we use 3.5 as a comfortable indicator)
    private static final double ATTACK_RANGE = 3.5;

    // Neon red ARGB components
    private static final int RED_R = 255;
    private static final int RED_G = 20;
    private static final int RED_B = 20;
    private static final int RED_A = 255;

    // Default white ARGB components
    private static final int WHITE_R = 255;
    private static final int WHITE_G = 255;
    private static final int WHITE_B = 255;
    private static final int WHITE_A = 90;

    @Inject(
        method = "renderNameTag",
        at = @At("HEAD")
    )
    private void greninja$colorHitbox(
        T entity,
        net.minecraft.network.chat.Component displayName,
        PoseStack poseStack,
        MultiBufferSource bufferSource,
        int packedLight,
        float partialTick,
        CallbackInfo ci
    ) {
        // Only act on player entities, not the local player themselves
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.player == null) return;
        if (!(entity instanceof Player target)) return;
        if (entity == mc.player) return;
        if (!mc.getEntityRenderDispatcher().shouldRenderHitBoxes()) return;

        double distance = mc.player.distanceTo(target);
        boolean inRange = distance <= ATTACK_RANGE;

        // Get the entity's bounding box relative to its render position
        AABB box = entity.getBoundingBox();
        double x = entity.getX();
        double y = entity.getY();
        double z = entity.getZ();

        // Offset the box to local render space
        double minX = box.minX - x;
        double minY = box.minY - y;
        double minZ = box.minZ - z;
        double maxX = box.maxX - x;
        double maxY = box.maxY - y;
        double maxZ = box.maxZ - z;

        VertexConsumer lines = bufferSource.getBuffer(RenderType.lines());

        int r = inRange ? RED_R : WHITE_R;
        int g = inRange ? RED_G : WHITE_G;
        int b = inRange ? RED_B : WHITE_B;
        int a = inRange ? RED_A : WHITE_A;

        // Draw all 12 edges of the bounding box cube
        greninja$drawBox(poseStack, lines, minX, minY, minZ, maxX, maxY, maxZ, r, g, b, a);
    }

    /**
     * Draws the 12 edges of an axis-aligned bounding box.
     */
    private static void greninja$drawBox(
        PoseStack poseStack, VertexConsumer lines,
        double minX, double minY, double minZ,
        double maxX, double maxY, double maxZ,
        int r, int g, int b, int a
    ) {
        PoseStack.Pose pose = poseStack.last();
        float fr = r / 255f;
        float fg = g / 255f;
        float fb = b / 255f;
        float fa = a / 255f;

        // Bottom face
        greninja$line(pose, lines, minX, minY, minZ, maxX, minY, minZ, fr, fg, fb, fa);
        greninja$line(pose, lines, maxX, minY, minZ, maxX, minY, maxZ, fr, fg, fb, fa);
        greninja$line(pose, lines, maxX, minY, maxZ, minX, minY, maxZ, fr, fg, fb, fa);
        greninja$line(pose, lines, minX, minY, maxZ, minX, minY, minZ, fr, fg, fb, fa);
        // Top face
        greninja$line(pose, lines, minX, maxY, minZ, maxX, maxY, minZ, fr, fg, fb, fa);
        greninja$line(pose, lines, maxX, maxY, minZ, maxX, maxY, maxZ, fr, fg, fb, fa);
        greninja$line(pose, lines, maxX, maxY, maxZ, minX, maxY, maxZ, fr, fg, fb, fa);
        greninja$line(pose, lines, minX, maxY, maxZ, minX, maxY, minZ, fr, fg, fb, fa);
        // Vertical edges
        greninja$line(pose, lines, minX, minY, minZ, minX, maxY, minZ, fr, fg, fb, fa);
        greninja$line(pose, lines, maxX, minY, minZ, maxX, maxY, minZ, fr, fg, fb, fa);
        greninja$line(pose, lines, maxX, minY, maxZ, maxX, maxY, maxZ, fr, fg, fb, fa);
        greninja$line(pose, lines, minX, minY, maxZ, minX, maxY, maxZ, fr, fg, fb, fa);
    }

    private static void greninja$line(
        PoseStack.Pose pose, VertexConsumer lines,
        double x1, double y1, double z1,
        double x2, double y2, double z2,
        float r, float g, float b, float a
    ) {
        // Direction normal for line rendering
        float dx = (float)(x2 - x1);
        float dy = (float)(y2 - y1);
        float dz = (float)(z2 - z1);
        float len = (float) Math.sqrt(dx*dx + dy*dy + dz*dz);
        if (len == 0) return;
        dx /= len; dy /= len; dz /= len;

        lines.addVertex(pose, (float)x1, (float)y1, (float)z1)
             .setColor(r, g, b, a)
             .setNormal(pose, dx, dy, dz);
        lines.addVertex(pose, (float)x2, (float)y2, (float)z2)
             .setColor(r, g, b, a)
             .setNormal(pose, dx, dy, dz);
    }
}
