package com.greninja.mod.mixin;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.UseAnim;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import net.minecraft.client.gui.Gui;

/**
 * Greninja - Shield Indicator Feature
 *
 * When a nearby player holds a shield:
 *   - NEON YELLOW outline = shield is active / blocking
 *   - NEON RED outline    = shield was just disabled by an axe
 *
 * Tracks shield-disabled state via a shared helper map updated
 * in the StutterFixMixin tick, since we have no direct server event.
 */
@Mixin(Gui.class)
public class ShieldIndicatorMixin {

    // How many ticks to show the "shield disabled" red indicator
    private static final int DISABLED_TICKS = 100; // 5 seconds at 20tps

    /**
     * Track which players have recently had their shield disabled.
     * key = entity id, value = ticks remaining to show disabled state
     */
    public static final java.util.concurrent.ConcurrentHashMap<Integer, Integer>
        SHIELD_DISABLED_MAP = new java.util.concurrent.ConcurrentHashMap<>();

    /**
     * Called by StutterFixMixin every tick to decrement timers.
     */
    public static void tickShieldDisabledMap() {
        SHIELD_DISABLED_MAP.entrySet().removeIf(e -> {
            e.setValue(e.getValue() - 1);
            return e.getValue() <= 0;
        });
    }

    /**
     * Called when we detect a player's shield was disabled (done in StutterFixMixin
     * by checking for the shield cooldown being applied).
     */
    public static void markShieldDisabled(int entityId) {
        SHIELD_DISABLED_MAP.put(entityId, DISABLED_TICKS);
    }

    /**
     * Checks if a player is actively using a shield RIGHT NOW.
     */
    private static boolean isBlockingWithShield(Player player) {
        ItemStack active = player.getUseItem();
        if (active.isEmpty()) return false;
        if (active.getItem() != Items.SHIELD) return false;
        return player.isUsingItem() && active.getUseAnimation() == UseAnim.BLOCK;
    }
}
