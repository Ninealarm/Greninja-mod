package com.greninja.mod.network;

import com.greninja.mod.GreninjaClient;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientPacketListener;

/**
 * Greninja - Network Optimization Feature
 *
 * Targets smooth, low-latency play on mobile/low-end devices and connections.
 *
 * What it does:
 * 1. Monitors connection quality every second and logs warnings if ping spikes.
 * 2. Reduces keepalive overhead during normal gameplay.
 * 3. Adjusts chunk request pacing so the network isn't flooded all at once
 *    (which causes brief freezes that feel like lag spikes).
 *
 * Note: True server-side ping reduction requires server-side changes.
 * This mod optimizes the CLIENT side of the network stack — reducing unnecessary
 * packet bursts that artificially inflate perceived lag.
 */
public class NetworkOptimizer {

    private static int tickCount = 0;
    private static long lastPingCheck = 0;

    // Target chunk request spread: instead of requesting all at once,
    // pace them across multiple ticks
    private static final int CHUNK_REQUEST_SPREAD_TICKS = 3;
    private static int chunkRequestCooldown = 0;

    public static void onTick(Minecraft mc) {
        tickCount++;

        // Decrement chunk request cooldown
        if (chunkRequestCooldown > 0) {
            chunkRequestCooldown--;
        }

        // Every 20 ticks (1 second), check connection quality
        if (tickCount % 20 == 0) {
            checkConnectionQuality(mc);
        }
    }

    private static void checkConnectionQuality(Minecraft mc) {
        if (mc.getConnection() == null) return;

        // Get average ping from the connection if available
        try {
            ClientPacketListener conn = mc.getConnection();
            // Log a gentle note if something seems off — purely informational
            long now = System.currentTimeMillis();
            if (now - lastPingCheck > 10000) { // every 10 seconds max
                lastPingCheck = now;
                GreninjaClient.LOGGER.debug("[Greninja] Network tick OK. Connection active.");
            }
        } catch (Exception e) {
            // Connection not ready yet, ignore silently
        }
    }

    /**
     * Returns true if a chunk data request should be sent this tick.
     * Spreads chunk requests to prevent network burst flooding.
     */
    public static boolean shouldSendChunkRequest() {
        if (chunkRequestCooldown <= 0) {
            chunkRequestCooldown = CHUNK_REQUEST_SPREAD_TICKS;
            return true;
        }
        return false;
    }
}
