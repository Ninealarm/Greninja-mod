package com.greninja.mod.hud;

import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.DeltaTracker;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;

/**
 * Greninja - Armor HUD Feature
 *
 * Draws a compact armor display in the bottom-left corner showing:
 * - Helmet, Chestplate, Leggings, Boots icons
 * - Durability bar under each piece (green → yellow → red as it wears)
 * - Exact durability numbers on hover (via F3 or always-on mode)
 *
 * Designed to be clean and not overlap with vanilla HUD elements.
 */
public class ArmorHudRenderer implements HudRenderCallback {

    // Position: bottom-left, just above the hotbar
    private static final int PADDING_X = 2;
    private static final int PADDING_Y_FROM_BOTTOM = 60;
    private static final int SLOT_SIZE = 16;
    private static final int SLOT_GAP = 2;

    // Durability bar size
    private static final int BAR_WIDTH = 16;
    private static final int BAR_HEIGHT = 2;

    @Override
    public void onHudRender(GuiGraphics graphics, DeltaTracker delta) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null) return;
        if (mc.options.hideGui) return;

        Player player = mc.player;
        int screenHeight = mc.getWindow().getGuiScaledHeight();

        // Armor slots in order: boots (0), leggings (1), chestplate (2), helmet (3)
        EquipmentSlot[] slots = {
            EquipmentSlot.FEET,
            EquipmentSlot.LEGS,
            EquipmentSlot.CHEST,
            EquipmentSlot.HEAD
        };

        for (int i = 0; i < slots.length; i++) {
            ItemStack stack = player.getItemBySlot(slots[i]);
            if (stack.isEmpty()) continue;

            int x = PADDING_X;
            int y = screenHeight - PADDING_Y_FROM_BOTTOM - (i * (SLOT_SIZE + BAR_HEIGHT + SLOT_GAP + 2));

            // Draw the item icon
            graphics.renderItem(stack, x, y);

            // Draw durability bar below the icon
            if (stack.isDamageableItem()) {
                int maxDur = stack.getMaxDamage();
                int curDur = maxDur - stack.getDamageValue();
                float fraction = (float) curDur / maxDur;

                // Background bar (dark)
                graphics.fill(x, y + SLOT_SIZE + 1, x + BAR_WIDTH, y + SLOT_SIZE + 1 + BAR_HEIGHT, 0xFF333333);

                // Foreground bar (color based on durability)
                int barColor = getDurabilityColor(fraction);
                int filledWidth = Math.max(1, (int)(fraction * BAR_WIDTH));
                graphics.fill(x, y + SLOT_SIZE + 1, x + filledWidth, y + SLOT_SIZE + 1 + BAR_HEIGHT, barColor);

                // Draw durability number to the right of the bar
                String durText = curDur + "";
                int textColor = getDurabilityColor(fraction);
                graphics.drawString(mc.font, durText, x + SLOT_SIZE + 2, y + SLOT_SIZE - 2, textColor, true);
            }
        }
    }

    /**
     * Returns ARGB color based on durability fraction:
     * >60% = green, 30-60% = yellow, <30% = red
     */
    private static int getDurabilityColor(float fraction) {
        if (fraction > 0.6f) {
            return 0xFF55FF55; // Green
        } else if (fraction > 0.3f) {
            return 0xFFFFFF55; // Yellow
        } else {
            return 0xFFFF5555; // Red
        }
    }
}
