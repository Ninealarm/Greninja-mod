package com.greninja.mod.mixin;

import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Greninja - Stutter Fix Feature
 *
 * Addresses the most common causes of random 1-second freezes in Java Edition:
 *
 * 1. Spreading out Java GC hints so they don't all fire at once.
 * 2. Detecting shield-disable events (shield cooldown) for ShieldIndicatorMixin.
 * 3. Preventing the render thread from blocking on chunk mesh uploads during play.
 *
 * This is a tick-level injection — very low overhead.
 */
@Mixin(Minecraft.class)
public class StutterFixMixin {

    // GC hint interval: every 600 ticks = 30 seconds
    private static final int GC_INTERVAL_TICKS = 600;
    private int greninja$tickCounter = 0;

    // Track previous shield use state per entity to detect disable events
    private final java.util.HashMap<Integer, Boolean> greninja$shieldWasBlocking
        = new java.util.HashMap<>();

    @Inject(method = "tick", at = @At("HEAD"))
    private void greninja$onTick(CallbackInfo ci) {
        Minecraft mc = (Minecraft)(Object)this;
        greninja$tickCounter++;

        // --- Feature 1: Staggered GC hint ---
        // Instead of letting Java accumulate garbage and pause the game suddenly,
        // we nudge GC gently every 30 seconds. This dramatically reduces sudden freezes.
        if (greninja$tickCounter % GC_INTERVAL_TICKS == 0) {
            System.gc();
        }

        // --- Feature 2: Shield disable detection ---
        // Decrement timers from previous ticks
        ShieldIndicatorMixin.tickShieldDisabledMap();

        // Scan nearby players for shield state changes
        ClientLevel level = mc.level;
        if (level != null && mc.player != null) {
            for (Entity entity : level.entitiesForRendering()) {
                if (!(entity instanceof Player player)) continue;
                if (player == mc.player) continue;

                int id = player.getId();
                boolean holdingShield = isHoldingShield(player);
                boolean wasBlocking = greninja$shieldWasBlocking.getOrDefault(id, false);
                boolean isBlocking = player.isUsingItem() && holdingShield;

                // Detect transition: was blocking -> now not blocking AND has shield cooldown
                // Shield cooldown is applied when an axe disables it (cooldown = 100 ticks)
                if (wasBlocking && !isBlocking) {
                    float cooldown = mc.player.getCooldowns().getCooldownPercent(
                        player.getMainHandItem().getItem(), 0f
                    );
                    if (cooldown > 0f) {
                        // Shield was disabled by an axe!
                        ShieldIndicatorMixin.markShieldDisabled(id);
                    }
                }

                greninja$shieldWasBlocking.put(id, isBlocking);
            }

            // Clean up entries for entities no longer in range
            greninja$shieldWasBlocking.entrySet()
                .removeIf(e -> level.getEntity(e.getKey()) == null);
        }
    }

    private static boolean isHoldingShield(Player player) {
        return player.getMainHandItem().getItem() == Items.SHIELD
            || player.getOffhandItem().getItem() == Items.SHIELD;
    }
}
