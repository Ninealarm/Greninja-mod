package com.greninja.mod.hud;

import com.greninja.mod.config.GreninjaConfig;
import com.greninja.mod.mixin.ShieldDisableData;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Items;

public class ShieldHudRenderer implements HudRenderCallback {
    private static final int COL_YELLOW = 0xFFFFFF00;
    private static final int COL_RED    = 0xFFFF2222;
    private static final int COL_GREEN  = 0xFF88FF88;
    private static final int COL_BG     = 0x88000000;

    @Override
    public void onHudRender(GuiGraphics g, DeltaTracker delta) {
        if (!GreninjaConfig.get().shieldIndicator) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null || mc.options.hideGui) return;

        int sw = mc.getWindow().getGuiScaledWidth();
        int y = 4;

        for (Player p : mc.level.players()) {
            if (p == mc.player) continue;
            if (mc.player.distanceTo(p) > 16.0) continue;

            boolean hasShield = p.getMainHandItem().getItem() == Items.SHIELD
                             || p.getOffhandItem().getItem()  == Items.SHIELD;
            if (!hasShield) continue;

            boolean disabled = ShieldDisableData.SHIELD_DISABLED.containsKey(p.getId());
            boolean blocking = p.isUsingItem() && p.getUseItem().getItem() == Items.SHIELD;

            String name = p.getName().getString();
            if (name.length() > 10) name = name.substring(0, 9) + "..";

            String status;
            int col;
            if (disabled)       { status = "DISABLED"; col = COL_RED; }
            else if (blocking)  { status = "BLOCKING";  col = COL_YELLOW; }
            else                { status = "HAS SHIELD"; col = COL_GREEN; }

            int lineX = sw / 2 - 50;
            g.fill(lineX - 2, y - 1, lineX + 104, y + 9, COL_BG);
            g.drawString(mc.font, name + " - " + status, lineX, y, col, true);
            y += 11;
        }

        // Clean up expired shield disable entries
        ShieldDisableData.SHIELD_DISABLED.entrySet().removeIf(e -> {
            e.setValue(e.getValue() - 1);
            return e.getValue() <= 0;
        });
    }
}
