package com.greninja.mod.mixin;

import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Items;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class ShieldDisableData {
    public static final ConcurrentHashMap<Integer, Integer> SHIELD_DISABLED = new ConcurrentHashMap<>();
    private static final Map<Integer, Boolean> wasOnCooldown = new HashMap<>();

    public static void tick() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null) return;
        for (Player p : mc.level.players()) {
            if (p == mc.player) continue;
            int id = p.getId();
            boolean hasShield = p.getMainHandItem().getItem() == Items.SHIELD
                             || p.getOffhandItem().getItem()  == Items.SHIELD;
            if (!hasShield) { wasOnCooldown.remove(id); SHIELD_DISABLED.remove(id); continue; }
            boolean onCooldown = p.getCooldowns().isOnCooldown(Items.SHIELD);
            boolean prev = wasOnCooldown.getOrDefault(id, false);
            if (onCooldown) { SHIELD_DISABLED.put(id, 100); }
            else { SHIELD_DISABLED.remove(id); }
            wasOnCooldown.put(id, onCooldown);
        }
    }
}
