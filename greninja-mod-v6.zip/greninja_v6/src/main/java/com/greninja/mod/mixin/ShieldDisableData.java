package com.greninja.mod.mixin;

import java.util.concurrent.ConcurrentHashMap;

public class ShieldDisableData {
    public static final ConcurrentHashMap<Integer, Integer> SHIELD_DISABLED = new ConcurrentHashMap<>();
}
