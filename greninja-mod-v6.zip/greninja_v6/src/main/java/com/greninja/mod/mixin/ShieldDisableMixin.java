package com.greninja.mod.mixin;

import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemCooldowns;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ItemCooldowns.class)
public class ShieldDisableMixin {

    @Inject(method = "addCooldown", at = @At("HEAD"))
    private void greninja$onCooldown(net.minecraft.world.item.Item item, int ticks, CallbackInfo ci) {
        if (ticks < 50) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null) return;
        for (Player p : mc.level.players()) {
            if (p.getCooldowns() == (Object) this) {
                ShieldDisableData.SHIELD_DISABLED.put(p.getId(), ticks);
                break;
            }
        }
    }
}
