package com.greninja.mod.hud;

import com.greninja.mod.config.GreninjaConfig;
import com.greninja.mod.mixin.ShieldDisableMixin;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Items;

public class ShieldHudRenderer implements HudRenderCallback {

    private static final int COL_YELLOW = 0xFFFFFF00;
    private static final int COL_RED    = 0xFFFF2222;
    private static final int COL_BG     = 0x88000000;

    @Override
    public void onHudRender(GuiGraphics g, DeltaTracker delta) {
        GreninjaConfig cfg = GreninjaConfig.get();
        if (!cfg.shieldIndicator) return;

        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null) return;
        if (mc.options.hideGui) return;

        int sw = mc.getWindow().getGuiScaledWidth();
        int y  = 4;
        int x  = sw / 2 - 60;

        boolean any = false;
        StringBuilder sb = new StringBuilder();

        for (Player p : mc.level.players()) {
            if (p == mc.player) continue;
            double dist = mc.player.distanceTo(p);
            if (dist > 16.0) continue;

            boolean hasShield = p.getMainHandItem().getItem() == Items.SHIELD
                             || p.getOffhandItem().getItem()  == Items.SHIELD;
            if (!hasShield) continue;

            boolean disabled  = ShieldDisableMixin.SHIELD_DISABLED.containsKey(p.getId());
            boolean blocking  = p.isUsingItem() && p.getUseItem().getItem() == Items.SHIELD;

            String name = p.getName().getString();
            if (name.length() > 8) name = name.substring(0, 7) + "..";

            String status;
            int col;
            if (disabled) {
                status = "DISABLED";
                col = COL_RED;
            } else if (blocking) {
                status = "BLOCKING";
                col = COL_YELLOW;
            } else {
                status = "HAS SHIELD";
                col = 0xFFAAFFAA;
            }

            // Background box
            int lineX = sw / 2 - 50;
            int lineY = y;
            g.fill(lineX - 2, lineY - 1, lineX + 102, lineY + 9, COL_BG);
            g.drawString(mc.font, name + " - " + status, lineX, lineY, col, true);
            y += 11;
            any = true;
        }
    }
}
