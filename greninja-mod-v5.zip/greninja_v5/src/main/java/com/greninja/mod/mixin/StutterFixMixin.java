package com.greninja.mod.mixin;

import com.greninja.mod.config.GreninjaConfig;
import net.minecraft.client.Minecraft;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Minecraft.class)
public class StutterFixMixin {
    private int greninja$ticks = 0;

    @Inject(method = "tick", at = @At("HEAD"))
    private void greninja$onTick(CallbackInfo ci) {
        if (!GreninjaConfig.get().stutterFixEnabled) return;
        if (++greninja$ticks % 600 == 0) System.gc();
    }
}
