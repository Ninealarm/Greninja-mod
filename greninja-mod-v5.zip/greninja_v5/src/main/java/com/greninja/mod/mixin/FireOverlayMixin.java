package com.greninja.mod.mixin;

import com.greninja.mod.config.GreninjaConfig;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiGraphics;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Gui.class)
public class FireOverlayMixin {

    @Inject(method = "renderFireOverlay", at = @At("HEAD"), cancellable = true)
    private void greninja$cancelFire(GuiGraphics g, CallbackInfo ci) {
        if (GreninjaConfig.get().lowFireEnabled) {
            ci.cancel();
        }
    }
}
