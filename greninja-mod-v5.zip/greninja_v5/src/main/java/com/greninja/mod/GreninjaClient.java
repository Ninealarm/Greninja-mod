package com.greninja.mod;

import com.greninja.mod.config.GreninjaConfig;
import com.greninja.mod.config.GreninjaConfigScreen;
import com.greninja.mod.hud.ArmorHudRenderer;
import com.greninja.mod.hud.ShieldHudRenderer;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import org.lwjgl.glfw.GLFW;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class GreninjaClient implements ClientModInitializer {
    public static final String MOD_ID = "greninja";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    public static KeyMapping openConfigKey;

    @Override
    public void onInitializeClient() {
        LOGGER.info("[Greninja] Loading v1.0 for Minecraft 1.21.11");

        GreninjaConfig.load();

        // Keybind: M key opens config screen
        openConfigKey = KeyBindingHelper.registerKeyBinding(new KeyMapping(
            "key.greninja.config",
            GLFW.GLFW_KEY_M,
            "category.greninja"
        ));

        // Register HUD renderers
        HudRenderCallback.EVENT.register(new ArmorHudRenderer());
        HudRenderCallback.EVENT.register(new ShieldHudRenderer());

        // Open config on keypress + handle fullbright
        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            while (openConfigKey.consumeClick()) {
                mc.setScreen(new GreninjaConfigScreen(mc.screen));
            }
            // Fullbright: override gamma option value every tick
            GreninjaConfig cfg = GreninjaConfig.get();
            if (cfg.fullbrightEnabled) {
                mc.options.gamma().set(cfg.fullbrightIntensity);
            }
        });

        LOGGER.info("[Greninja] Loaded successfully");
    }
}
