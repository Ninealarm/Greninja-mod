package com.greninja.mod.mixin;

import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemCooldowns;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.concurrent.ConcurrentHashMap;

@Mixin(ItemCooldowns.class)
public class ShieldDisableMixin {

    // entityId -> ticks remaining shown as disabled
    public static final ConcurrentHashMap<Integer, Integer> SHIELD_DISABLED =
        new ConcurrentHashMap<>();

    @Inject(method = "addCooldown", at = @At("HEAD"))
    private void greninja$onCooldown(net.minecraft.world.item.Item item, int ticks, CallbackInfo ci) {
        if (ticks < 50) return; // shield disable is 100 ticks
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null) return;

        // Find which player this cooldown belongs to
        for (Player p : mc.level.players()) {
            if (p.getCooldowns() == (Object)this) {
                SHIELD_DISABLED.put(p.getId(), ticks);
                break;
            }
        }
    }
}
