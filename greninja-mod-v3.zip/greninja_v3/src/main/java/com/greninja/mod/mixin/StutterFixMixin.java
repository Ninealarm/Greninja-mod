package com.greninja.mod.mixin;

import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Items;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Minecraft.class)
public class StutterFixMixin {
    private static final int GC_INTERVAL = 600;
    private int greninja$ticks = 0;
    private final java.util.HashMap<Integer, Boolean> greninja$wasBlocking = new java.util.HashMap<>();

    @Inject(method = "tick", at = @At("HEAD"))
    private void greninja$tick(CallbackInfo ci) {
        Minecraft mc = (Minecraft)(Object)this;
        greninja$ticks++;

        // Staggered GC to prevent random freezes
        if (greninja$ticks % GC_INTERVAL == 0) System.gc();

        ShieldIndicatorMixin.tickMap();

        ClientLevel level = mc.level;
        if (level == null || mc.player == null) return;

        for (Entity entity : level.entitiesForRendering()) {
            if (!(entity instanceof Player p)) continue;
            if (p == mc.player) continue;

            int id = p.getId();
            boolean holding = p.getMainHandItem().getItem() == Items.SHIELD
                           || p.getOffhandItem().getItem() == Items.SHIELD;
            boolean wasBlocking = greninja$wasBlocking.getOrDefault(id, false);
            boolean isBlocking = p.isUsingItem() && holding;

            if (wasBlocking && !isBlocking) {
                float cd = mc.player.getCooldowns()
                    .getCooldownPercent(p.getMainHandItem().getItem(), 0f);
                if (cd > 0f) ShieldIndicatorMixin.markDisabled(id);
            }
            greninja$wasBlocking.put(id, isBlocking);
        }
        greninja$wasBlocking.entrySet()
            .removeIf(e -> level.getEntity(e.getKey()) == null);
    }
}
