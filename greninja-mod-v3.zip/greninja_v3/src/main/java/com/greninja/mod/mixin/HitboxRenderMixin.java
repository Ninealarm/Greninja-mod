package com.greninja.mod.mixin;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.AABB;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(EntityRenderer.class)
public class HitboxRenderMixin<T extends Entity> {
    private static final double RANGE = 3.5;

    @Inject(method = "renderNameTag", at = @At("HEAD"))
    private void greninja$hitbox(T entity, Component name,
            PoseStack ps, MultiBufferSource buf,
            int light, float delta, CallbackInfo ci) {

        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.player == null) return;
        if (!(entity instanceof Player target)) return;
        if (entity == mc.player) return;
        if (!mc.getEntityRenderDispatcher().shouldRenderHitBoxes()) return;

        boolean inRange = mc.player.distanceTo(target) <= RANGE;
        float r = inRange ? 1.0f : 1.0f;
        float g = inRange ? 0.05f : 1.0f;
        float b = inRange ? 0.05f : 1.0f;
        float a = inRange ? 1.0f : 0.35f;

        AABB box = entity.getBoundingBox();
        double ex = entity.getX(), ey = entity.getY(), ez = entity.getZ();

        VertexConsumer vc = buf.getBuffer(RenderType.lines());
        drawBox(ps, vc,
            box.minX-ex, box.minY-ey, box.minZ-ez,
            box.maxX-ex, box.maxY-ey, box.maxZ-ez,
            r, g, b, a);
    }

    private static void drawBox(PoseStack ps, VertexConsumer vc,
            double x1,double y1,double z1,double x2,double y2,double z2,
            float r,float g,float b,float a) {
        ln(ps,vc,x1,y1,z1,x2,y1,z1,r,g,b,a); ln(ps,vc,x2,y1,z1,x2,y1,z2,r,g,b,a);
        ln(ps,vc,x2,y1,z2,x1,y1,z2,r,g,b,a); ln(ps,vc,x1,y1,z2,x1,y1,z1,r,g,b,a);
        ln(ps,vc,x1,y2,z1,x2,y2,z1,r,g,b,a); ln(ps,vc,x2,y2,z1,x2,y2,z2,r,g,b,a);
        ln(ps,vc,x2,y2,z2,x1,y2,z2,r,g,b,a); ln(ps,vc,x1,y2,z2,x1,y2,z1,r,g,b,a);
        ln(ps,vc,x1,y1,z1,x1,y2,z1,r,g,b,a); ln(ps,vc,x2,y1,z1,x2,y2,z1,r,g,b,a);
        ln(ps,vc,x2,y1,z2,x2,y2,z2,r,g,b,a); ln(ps,vc,x1,y1,z2,x1,y2,z2,r,g,b,a);
    }

    private static void ln(PoseStack ps, VertexConsumer vc,
            double x1,double y1,double z1,double x2,double y2,double z2,
            float r,float g,float b,float a) {
        float dx=(float)(x2-x1),dy=(float)(y2-y1),dz=(float)(z2-z1);
        float len=(float)Math.sqrt(dx*dx+dy*dy+dz*dz);
        if(len==0)return; dx/=len;dy/=len;dz/=len;
        var pose=ps.last();
        vc.addVertex(pose,(float)x1,(float)y1,(float)z1).setColor(r,g,b,a).setNormal(pose,dx,dy,dz);
        vc.addVertex(pose,(float)x2,(float)y2,(float)z2).setColor(r,g,b,a).setNormal(pose,dx,dy,dz);
    }
}
