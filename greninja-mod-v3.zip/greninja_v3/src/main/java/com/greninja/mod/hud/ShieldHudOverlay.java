package com.greninja.mod.hud;

import com.greninja.mod.mixin.ShieldIndicatorMixin;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.UseAnim;
import net.minecraft.world.phys.AABB;

public class ShieldHudOverlay {
    private static final float YR=1f,YG=1f,YB=0f,YA=1f; // yellow
    private static final float RR=1f,RG=0.05f,RB=0.05f,RA=1f; // red
    private static final double EX = 0.05;

    public static void register() {
        WorldRenderEvents.AFTER_ENTITIES.register(ShieldHudOverlay::render);
    }

    private static void render(WorldRenderContext ctx) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.player == null) return;

        PoseStack ps = ctx.matrixStack();
        if (ps == null) return;

        MultiBufferSource.BufferSource buf = mc.renderBuffers().bufferSource();
        var cam = mc.gameRenderer.getMainCamera().getPosition();

        for (Entity e : mc.level.entitiesForRendering()) {
            if (!(e instanceof Player p)) continue;
            if (p == mc.player) continue;

            boolean blocking = isBlocking(p);
            boolean disabled = ShieldIndicatorMixin.SHIELD_DISABLED_MAP.containsKey(p.getId());
            if (!blocking && !disabled) continue;

            float r,g,b,a;
            if (disabled) { r=RR;g=RG;b=RB;a=RA; }
            else { r=YR;g=YG;b=YB;a=YA; }

            AABB box = p.getBoundingBox().inflate(EX);
            ps.pushPose();
            ps.translate(box.minX-cam.x, box.minY-cam.y, box.minZ-cam.z);
            double w=box.maxX-box.minX, h=box.maxY-box.minY, d=box.maxZ-box.minZ;
            VertexConsumer vc = buf.getBuffer(RenderType.lines());
            drawBox(ps,vc,0,0,0,w,h,d,r,g,b,a);
            ps.popPose();
        }
        buf.endBatch(RenderType.lines());
    }

    private static boolean isBlocking(Player p) {
        if (!p.isUsingItem()) return false;
        var item = p.getUseItem();
        return item.getItem()==Items.SHIELD && item.getUseAnimation()==UseAnim.BLOCK;
    }

    private static void drawBox(PoseStack ps, VertexConsumer vc,
            double x1,double y1,double z1,double x2,double y2,double z2,
            float r,float g,float b,float a) {
        ln(ps,vc,x1,y1,z1,x2,y1,z1,r,g,b,a); ln(ps,vc,x2,y1,z1,x2,y1,z2,r,g,b,a);
        ln(ps,vc,x2,y1,z2,x1,y1,z2,r,g,b,a); ln(ps,vc,x1,y1,z2,x1,y1,z1,r,g,b,a);
        ln(ps,vc,x1,y2,z1,x2,y2,z1,r,g,b,a); ln(ps,vc,x2,y2,z1,x2,y2,z2,r,g,b,a);
        ln(ps,vc,x2,y2,z2,x1,y2,z2,r,g,b,a); ln(ps,vc,x1,y2,z2,x1,y2,z1,r,g,b,a);
        ln(ps,vc,x1,y1,z1,x1,y2,z1,r,g,b,a); ln(ps,vc,x2,y1,z1,x2,y2,z1,r,g,b,a);
        ln(ps,vc,x2,y1,z2,x2,y2,z2,r,g,b,a); ln(ps,vc,x1,y1,z2,x1,y2,z2,r,g,b,a);
    }

    private static void ln(PoseStack ps, VertexConsumer vc,
            double x1,double y1,double z1,double x2,double y2,double z2,
            float r,float g,float b,float a) {
        float dx=(float)(x2-x1),dy=(float)(y2-y1),dz=(float)(z2-z1);
        float len=(float)Math.sqrt(dx*dx+dy*dy+dz*dz);
        if(len==0)return; dx/=len;dy/=len;dz/=len;
        var pose=ps.last();
        vc.addVertex(pose,(float)x1,(float)y1,(float)z1).setColor(r,g,b,a).setNormal(pose,dx,dy,dz);
        vc.addVertex(pose,(float)x2,(float)y2,(float)z2).setColor(r,g,b,a).setNormal(pose,dx,dy,dz);
    }
}
