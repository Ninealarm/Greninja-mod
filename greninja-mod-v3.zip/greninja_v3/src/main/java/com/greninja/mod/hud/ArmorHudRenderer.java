package com.greninja.mod.hud;

import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;

public class ArmorHudRenderer implements HudRenderCallback {
    private static final int X = 2;
    private static final int Y_FROM_BOTTOM = 60;
    private static final int SIZE = 16;
    private static final int GAP = 2;
    private static final int BAR_W = 16;
    private static final int BAR_H = 2;

    @Override
    public void onHudRender(GuiGraphics graphics, DeltaTracker delta) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null) return;
        if (mc.options.hideGui) return;

        Player player = mc.player;
        int screenH = mc.getWindow().getGuiScaledHeight();

        EquipmentSlot[] slots = {
            EquipmentSlot.FEET, EquipmentSlot.LEGS,
            EquipmentSlot.CHEST, EquipmentSlot.HEAD
        };

        for (int i = 0; i < slots.length; i++) {
            ItemStack stack = player.getItemBySlot(slots[i]);
            if (stack.isEmpty()) continue;

            int x = X;
            int y = screenH - Y_FROM_BOTTOM - (i * (SIZE + BAR_H + GAP + 2));

            graphics.renderItem(stack, x, y);

            if (stack.isDamageableItem()) {
                int maxDur = stack.getMaxDamage();
                int curDur = maxDur - stack.getDamageValue();
                float frac = (float) curDur / maxDur;

                // Dark background bar
                graphics.fill(x, y + SIZE + 1, x + BAR_W, y + SIZE + 1 + BAR_H, 0xFF333333);
                // Colored foreground bar
                int color = getColor(frac);
                int filled = Math.max(1, (int)(frac * BAR_W));
                graphics.fill(x, y + SIZE + 1, x + filled, y + SIZE + 1 + BAR_H, color);
                // Durability number
                graphics.drawString(mc.font, String.valueOf(curDur),
                    x + SIZE + 2, y + SIZE - 2, color, true);
            }
        }
    }

    private static int getColor(float f) {
        if (f > 0.6f) return 0xFF55FF55;
        else if (f > 0.3f) return 0xFFFFFF55;
        else return 0xFFFF5555;
    }
}
