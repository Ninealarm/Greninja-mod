package com.greninja.mod.mixin;

import net.minecraft.client.gui.Gui;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.UseAnim;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(Gui.class)
public class ShieldIndicatorMixin {
    public static final java.util.concurrent.ConcurrentHashMap<Integer, Integer>
        SHIELD_DISABLED_MAP = new java.util.concurrent.ConcurrentHashMap<>();

    public static void tickMap() {
        SHIELD_DISABLED_MAP.entrySet().removeIf(e -> {
            e.setValue(e.getValue() - 1);
            return e.getValue() <= 0;
        });
    }

    public static void markDisabled(int id) {
        SHIELD_DISABLED_MAP.put(id, 100);
    }

    public static boolean isBlocking(Player p) {
        if (!p.isUsingItem()) return false;
        var item = p.getUseItem();
        return item.getItem() == Items.SHIELD && item.getUseAnimation() == UseAnim.BLOCK;
    }
}
