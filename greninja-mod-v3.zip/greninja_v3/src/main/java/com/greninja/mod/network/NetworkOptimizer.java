package com.greninja.mod.network;

import net.minecraft.client.Minecraft;

public class NetworkOptimizer {
    private static int ticks = 0;

    public static void onTick(Minecraft mc) {
        ticks++;
        if (ticks % 200 != 0) return;
        checkConnectionQuality(mc);
    }

    private static void checkConnectionQuality(Minecraft mc) {
        if (mc.getConnection() == null) return;
        var connection = mc.getConnection().getConnection();
        if (connection == null) return;
        if (!connection.isConnected()) return;
        // Flush any pending packets to reduce latency spikes
        connection.channel().flush();
    }
}
