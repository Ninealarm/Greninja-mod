package com.greninja.mod.hud;

import com.greninja.mod.config.GreninjaConfig;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.world.food.FoodData;

public class SaturationHudRenderer implements HudRenderCallback {

    // Saturation bar renders just above the vanilla hunger bar
    // Vanilla hunger bar is at: y = screenH - 39, x starts at screenW/2 + 9
    // Each hunger icon is 8px wide, 10 icons total = 80px wide

    private static final int BAR_H  = 3;
    private static final int BAR_W  = 80;
    // Neon yellow-green for saturation
    private static final int COL_HIGH   = 0xFFAAFF00; // full sat - neon green-yellow
    private static final int COL_MED    = 0xFFFFDD00; // medium - yellow
    private static final int COL_LOW    = 0xFFFF6600; // low - orange
    private static final int COL_BG     = 0x88222200;

    @Override
    public void onHudRender(GuiGraphics g, DeltaTracker delta) {
        if (!GreninjaConfig.get().saturationBar) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.options.hideGui) return;
        // Don't show in creative/spectator
        if (!mc.player.canEat(false) && mc.player.getFoodData().getFoodLevel() == 20) return;

        FoodData food = mc.player.getFoodData();
        float saturation = food.getSaturationLevel();
        float maxSat = 20.0f; // max saturation matches max hunger
        float ratio = Math.min(1.0f, saturation / maxSat);

        int sw = mc.getWindow().getGuiScaledWidth();
        int sh = mc.getWindow().getGuiScaledHeight();

        // Position: right side above hunger bar (mirrored like vanilla hunger icons)
        int barX = sw / 2 + 9;
        int barY = sh - 44; // just above hunger bar

        // Background
        g.fill(barX, barY, barX + BAR_W, barY + BAR_H, COL_BG);

        // Saturation fill
        int fill = (int)(ratio * BAR_W);
        int col = ratio > 0.6f ? COL_HIGH : ratio > 0.3f ? COL_MED : COL_LOW;
        if (fill > 0) g.fill(barX, barY, barX + fill, barY + BAR_H, col);

        // Label
        String label = "§7Sat: " + (int)saturation;
        g.drawString(mc.font, label, barX, barY - 9, col, true);
    }
}
