package com.greninja.mod.util;

import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class ShieldDisableData {
    public static final ConcurrentHashMap<Integer, Integer> SHIELD_DISABLED = new ConcurrentHashMap<>();
    private static final Map<Integer, Boolean> wasOnCooldown = new HashMap<>();

    public static void tick() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null) return;
        for (Player p : mc.level.players()) {
            if (p == mc.player) continue;
            int id = p.getId();

            ItemStack main = p.getMainHandItem();
            ItemStack off  = p.getOffhandItem();
            boolean hasShield = main.getItem() == Items.SHIELD || off.getItem() == Items.SHIELD;

            if (!hasShield) {
                wasOnCooldown.remove(id);
                SHIELD_DISABLED.remove(id);
                continue;
            }

            ItemStack shieldStack = main.getItem() == Items.SHIELD ? main : off;
            boolean onCooldown = p.getCooldowns().isOnCooldown(shieldStack);

            if (onCooldown) {
                SHIELD_DISABLED.put(id, 100);
            } else {
                SHIELD_DISABLED.remove(id);
            }
            wasOnCooldown.put(id, onCooldown);
        }
    }
}
