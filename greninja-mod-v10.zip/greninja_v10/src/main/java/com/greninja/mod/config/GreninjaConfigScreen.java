package com.greninja.mod.config;

import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

public class GreninjaConfigScreen extends Screen {
    private final Screen parent;
    private static final double[] BRIGHTNESS_LEVELS = {1.0,2.0,4.0,6.0,8.0,10.0,15.0,20.0,50.0,100.0};
    private static final String[] BRIGHTNESS_NAMES  = {"1x","2x","4x","6x","8x","10x","15x","20x","50x","MAX"};

    public GreninjaConfigScreen(Screen parent) {
        super(Component.literal("Greninja Settings"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        int cx = this.width / 2;
        int bw = 220, bh = 20, gap = 24, y = 35;

        addToggle(cx, y,         bw, bh, "§bShield Indicator",
            () -> GreninjaConfig.get().shieldIndicator,
            () -> GreninjaConfig.get().shieldIndicator = !GreninjaConfig.get().shieldIndicator);

        addToggle(cx, y+gap,     bw, bh, "§aArmor / Durability HUD",
            () -> GreninjaConfig.get().armorHudEnabled,
            () -> GreninjaConfig.get().armorHudEnabled = !GreninjaConfig.get().armorHudEnabled);

        addToggle(cx, y+gap*2,   bw, bh, "§eSaturation Bar",
            () -> GreninjaConfig.get().saturationBar,
            () -> GreninjaConfig.get().saturationBar = !GreninjaConfig.get().saturationBar);

        addToggle(cx, y+gap*3,   bw, bh, "§cHitbox Color (range highlight)",
            () -> GreninjaConfig.get().hitboxEnabled,
            () -> GreninjaConfig.get().hitboxEnabled = !GreninjaConfig.get().hitboxEnabled);

        addToggle(cx, y+gap*4,   bw, bh, "§eFullbright",
            () -> GreninjaConfig.get().fullbrightEnabled,
            () -> GreninjaConfig.get().fullbrightEnabled = !GreninjaConfig.get().fullbrightEnabled);

        // Brightness row
        int iy = y + gap*5;
        int idx = findBrightnessIndex(GreninjaConfig.get().fullbrightIntensity);
        this.addRenderableWidget(Button.builder(Component.literal("§7◀"),
            b -> { int i = Math.max(0, findBrightnessIndex(GreninjaConfig.get().fullbrightIntensity)-1);
                   GreninjaConfig.get().fullbrightIntensity = BRIGHTNESS_LEVELS[i];
                   GreninjaConfig.save(); rebuildWidgets(); })
            .bounds(cx-110, iy, 25, bh).build());
        this.addRenderableWidget(Button.builder(
            Component.literal("§eBrightness: §f" + BRIGHTNESS_NAMES[idx]),
            b -> {}).bounds(cx-80, iy, 160, bh).build());
        this.addRenderableWidget(Button.builder(Component.literal("§7▶"),
            b -> { int i = Math.min(BRIGHTNESS_LEVELS.length-1, findBrightnessIndex(GreninjaConfig.get().fullbrightIntensity)+1);
                   GreninjaConfig.get().fullbrightIntensity = BRIGHTNESS_LEVELS[i];
                   GreninjaConfig.save(); rebuildWidgets(); })
            .bounds(cx+85, iy, 25, bh).build());

        this.addRenderableWidget(Button.builder(Component.literal("Done"),
            b -> { GreninjaConfig.save(); this.minecraft.setScreen(parent); })
            .bounds(cx-50, this.height-28, 100, 20).build());
    }

    private int findBrightnessIndex(double val) {
        for (int i = 0; i < BRIGHTNESS_LEVELS.length; i++)
            if (BRIGHTNESS_LEVELS[i] >= val) return i;
        return BRIGHTNESS_LEVELS.length-1;
    }

    private void addToggle(int cx, int y, int bw, int bh, String label,
                           java.util.function.BooleanSupplier getter, Runnable toggler) {
        boolean on = getter.getAsBoolean();
        this.addRenderableWidget(Button.builder(
            Component.literal(label + ": " + (on ? "§aON" : "§cOFF")),
            b -> { toggler.run(); GreninjaConfig.save(); rebuildWidgets(); })
            .bounds(cx-bw/2, y, bw, bh).build());
    }

    @Override
    public void render(net.minecraft.client.gui.GuiGraphics g, int mx, int my, float delta) {
        this.renderBackground(g, mx, my, delta);
        g.drawCenteredString(this.font, "§6§lGreninja Settings", this.width/2, 15, 0xFFFFFFFF);
        g.drawCenteredString(this.font, "§7Press M to open anytime", this.width/2, 25, 0xFFAAAAAA);
        super.render(g, mx, my, delta);
    }

    @Override public boolean isPauseScreen() { return false; }
}
