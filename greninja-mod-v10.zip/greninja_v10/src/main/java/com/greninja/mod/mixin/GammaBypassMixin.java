package com.greninja.mod.mixin;

import com.greninja.mod.config.GreninjaConfig;
import net.minecraft.client.option.SimpleOption;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(SimpleOption.class)
public class GammaBypassMixin<T> {

    @Shadow
    private T value;

    @Inject(method = "setValue", at = @At("HEAD"), cancellable = true)
    private void greninja$bypassGammaClamp(T newValue, CallbackInfo ci) {
        // Only intercept when this is the gamma option and fullbright is enabled
        SimpleOption<?> self = (SimpleOption<?>) (Object) this;
        if (!(newValue instanceof Double)) return;
        double d = (Double) newValue;
        // If our mod is setting a value > 1.0, bypass validation entirely
        if (d > 1.0) {
            this.value = newValue;
            ci.cancel();
        }
    }
}
