package com.greninja.mod.hud;

import com.greninja.mod.config.GreninjaConfig;
import com.greninja.mod.util.ShieldDisableData;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Items;
import net.minecraft.world.phys.AABB;
import org.joml.Matrix4f;
import org.joml.Vector3f;
import org.joml.Vector4f;

public class HitboxAndShieldHudRenderer implements HudRenderCallback {

    // Neon colors
    private static final int NEON_RED    = 0xFFFF1133;
    private static final int NEON_YELLOW = 0xFFFFEE00;
    private static final int NEON_WHITE  = 0xFFDDEEFF;
    private static final int NEON_GREEN  = 0xFF44FF88;

    @Override
    public void onHudRender(GuiGraphics g, DeltaTracker delta) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null || mc.options.hideGui) return;
        if (mc.gameRenderer == null) return;

        GreninjaConfig cfg = GreninjaConfig.get();

        for (Player target : mc.level.players()) {
            if (target == mc.player) continue;
            double dist = mc.player.distanceTo(target);
            if (dist > 20.0) continue;

            boolean inRange    = dist <= cfg.attackRange + 0.5f;
            boolean hasShield  = target.getMainHandItem().getItem() == Items.SHIELD
                              || target.getOffhandItem().getItem()  == Items.SHIELD;
            boolean isBlocking = target.isUsingItem()
                              && target.getUseItem().getItem() == Items.SHIELD;
            boolean isDisabled = ShieldDisableData.SHIELD_DISABLED.containsKey(target.getId());

            // Hitbox color: neon red if in range, white if not
            if (cfg.hitboxEnabled && mc.getEntityRenderDispatcher().shouldRenderHitBoxes()) {
                int hitboxColor = inRange ? NEON_RED : NEON_WHITE;
                drawEntityBoxOnHud(g, mc, target, hitboxColor, delta.getGameTimeDeltaPartialTick(true));
            }

            // Shield border indicator on HUD (name tag area)
            if (cfg.shieldIndicator && hasShield) {
                int shieldColor;
                String shieldText;
                if (isDisabled)       { shieldColor = NEON_RED;    shieldText = "✗ DISABLED"; }
                else if (isBlocking)  { shieldColor = NEON_YELLOW; shieldText = "⬛ BLOCKING"; }
                else                  { shieldColor = NEON_GREEN;  shieldText = "✔ SHIELD";   }

                // Project entity position to screen and draw above nametag
                float[] screen = worldToScreen(mc, target, delta.getGameTimeDeltaPartialTick(true));
                if (screen != null && screen[2] > 0) {
                    int sx = (int) screen[0];
                    int sy = (int) screen[1] - 20;
                    int sw2 = mc.font.width(shieldText);
                    // Background pill
                    g.fill(sx - sw2/2 - 2, sy - 1, sx + sw2/2 + 2, sy + 9, 0xAA000000);
                    // Colored border
                    g.fill(sx - sw2/2 - 3, sy - 2, sx + sw2/2 + 3, sy - 1,  shieldColor);
                    g.fill(sx - sw2/2 - 3, sy + 9, sx + sw2/2 + 3, sy + 10, shieldColor);
                    g.fill(sx - sw2/2 - 3, sy - 2, sx - sw2/2 - 2, sy + 10, shieldColor);
                    g.fill(sx + sw2/2 + 2, sy - 2, sx + sw2/2 + 3, sy + 10, shieldColor);
                    // Text
                    g.drawCenteredString(mc.font, shieldText, sx, sy, shieldColor);
                }
            }
        }
    }

    /**
     * Project a world position to screen 2D coords.
     * Returns [screenX, screenY, w] or null if behind camera.
     */
    private float[] worldToScreen(Minecraft mc, Player target, float partialTick) {
        try {
            double ex = target.xo + (target.getX() - target.xo) * partialTick;
            double ey = target.yo + (target.getY() - target.yo) * partialTick + target.getBbHeight() + 0.5;
            double ez = target.zo + (target.getZ() - target.zo) * partialTick;

            double cx = mc.player.xo + (mc.player.getX() - mc.player.xo) * partialTick;
            double cy = mc.player.yo + (mc.player.getY() - mc.player.yo) * partialTick + mc.player.getEyeHeight();
            double cz = mc.player.zo + (mc.player.getZ() - mc.player.zo) * partialTick;

            float rx = (float)(ex - cx);
            float ry = (float)(ey - cy);
            float rz = (float)(ez - cz);

            Matrix4f proj = new Matrix4f(mc.gameRenderer.getMainCamera().getProjectionMatrix());
            // Build view from camera yaw/pitch
            float yaw   = (float) Math.toRadians(mc.player.getViewYRot(partialTick));
            float pitch = (float) Math.toRadians(mc.player.getViewXRot(partialTick));

            // Rotate relative position by camera
            float sinYaw   = (float) Math.sin(yaw);
            float cosYaw   = (float) Math.cos(yaw);
            float sinPitch = (float) Math.sin(pitch);
            float cosPitch = (float) Math.cos(pitch);

            float x1 = rx * cosYaw  - rz * sinYaw;
            float z1 = rx * sinYaw  + rz * cosYaw;
            float y1 = ry * cosPitch - z1 * sinPitch;
            float z2 = ry * sinPitch + z1 * cosPitch;

            if (z2 >= 0) return null; // behind camera

            Vector4f clip = proj.transform(new Vector4f(x1, y1, z2, 1.0f));
            if (clip.w <= 0) return null;

            float ndcX = clip.x / clip.w;
            float ndcY = clip.y / clip.w;

            int screenW = mc.getWindow().getGuiScaledWidth();
            int screenH = mc.getWindow().getGuiScaledHeight();
            float sx = (ndcX + 1f) / 2f * screenW;
            float sy = (1f - ndcY) / 2f * screenH;

            return new float[]{sx, sy, clip.w};
        } catch (Exception e) {
            return null;
        }
    }

    /**
     * Draw a 2D bounding box outline on screen projected from entity AABB.
     */
    private void drawEntityBoxOnHud(GuiGraphics g, Minecraft mc, Player target, int color, float partialTick) {
        try {
            AABB bb = target.getBoundingBox();
            // Project 4 key corners (just use top and bottom center for a simple bracket)
            float[] top = worldToScreen(mc, target, partialTick);
            if (top == null) return;

            double ox = target.xo + (target.getX() - target.xo) * partialTick;
            double oz = target.zo + (target.getZ() - target.zo) * partialTick;

            // Approximate screen box width from distance
            double dist = mc.player.distanceTo(target);
            int screenW = mc.getWindow().getGuiScaledWidth();
            int screenH = mc.getWindow().getGuiScaledHeight();

            // Size scales with distance
            int boxH = (int) Math.max(10, Math.min(120, screenH * 0.7 / dist));
            int boxW = (int)(boxH * 0.5f);

            int cx = (int) top[0];
            int cy = (int) top[1];
            int x1 = cx - boxW/2;
            int y1 = cy - boxH/2;
            int x2 = cx + boxW/2;
            int y2 = cy + boxH/2;

            // Clip to screen
            x1 = Math.max(0, x1); y1 = Math.max(0, y1);
            x2 = Math.min(screenW, x2); y2 = Math.min(screenH, y2);
            if (x2 <= x1 || y2 <= y1) return;

            int thick = 2;
            // Top line
            g.fill(x1, y1, x2, y1 + thick, color);
            // Bottom line
            g.fill(x1, y2 - thick, x2, y2, color);
            // Left line
            g.fill(x1, y1, x1 + thick, y2, color);
            // Right line
            g.fill(x2 - thick, y1, x2, y2, color);

        } catch (Exception ignored) {}
    }
}
