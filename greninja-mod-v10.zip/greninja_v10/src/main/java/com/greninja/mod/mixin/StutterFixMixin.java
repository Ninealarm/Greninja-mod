package com.greninja.mod.mixin;

import net.minecraft.client.Minecraft;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Minecraft.class)
public class StutterFixMixin {
    // Removed System.gc() - it causes worse GC pauses on Android/mobile JVM
    // The stutter fix is now handled by the render distance and chunk settings
    // that the mod sets automatically on first load
}
