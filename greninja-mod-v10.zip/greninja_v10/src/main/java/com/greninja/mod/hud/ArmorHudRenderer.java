package com.greninja.mod.hud;

import com.greninja.mod.config.GreninjaConfig;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;

public class ArmorHudRenderer implements HudRenderCallback {
    private static final int ITEM_SIZE = 16;
    private static final int BAR_W = 16, BAR_H = 2;
    private static final int ROW_H = ITEM_SIZE + BAR_H + 5;

    @Override
    public void onHudRender(GuiGraphics g, DeltaTracker delta) {
        GreninjaConfig cfg = GreninjaConfig.get();
        if (!cfg.armorHudEnabled) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null || mc.options.hideGui) return;

        int sh = mc.getWindow().getGuiScaledHeight();
        int x = cfg.armorHudX;
        int baseY = cfg.armorHudY < 0 ? sh + cfg.armorHudY : cfg.armorHudY;
        Player player = mc.player;

        EquipmentSlot[] slots = { EquipmentSlot.FEET, EquipmentSlot.LEGS, EquipmentSlot.CHEST, EquipmentSlot.HEAD };
        for (int i = 0; i < slots.length; i++) {
            ItemStack stack = player.getItemBySlot(slots[i]);
            if (!stack.isEmpty()) renderRow(g, mc, stack, x, baseY - (i * ROW_H));
        }

        // Main hand
        ItemStack held = player.getMainHandItem();
        if (!held.isEmpty() && held.isDamageableItem())
            renderRow(g, mc, held, x, baseY - (slots.length * ROW_H) - 4);

        // Offhand
        ItemStack offhand = player.getOffhandItem();
        if (!offhand.isEmpty() && offhand.isDamageableItem())
            renderRow(g, mc, offhand, x, baseY - (slots.length * ROW_H) - 4 - ROW_H);
    }

    private void renderRow(GuiGraphics g, Minecraft mc, ItemStack stack, int x, int y) {
        g.renderItem(stack, x, y);
        if (stack.isDamageableItem()) {
            int max = stack.getMaxDamage();
            int cur = max - stack.getDamageValue();
            float f = (float) cur / max;
            int col = f > 0.6f ? 0xFF55FF55 : f > 0.3f ? 0xFFFFFF55 : 0xFFFF4444;
            int fill = Math.max(1, (int)(f * BAR_W));
            int barY = y + ITEM_SIZE + 1;
            g.fill(x, barY, x + BAR_W, barY + BAR_H, 0xFF222222);
            g.fill(x, barY, x + fill, barY + BAR_H, col);
            String txt = cur >= 1000 ? (cur/1000) + "k" : String.valueOf(cur);
            g.drawString(mc.font, txt, x + ITEM_SIZE + 2, y + ITEM_SIZE - 7, col, true);
        }
    }
}
