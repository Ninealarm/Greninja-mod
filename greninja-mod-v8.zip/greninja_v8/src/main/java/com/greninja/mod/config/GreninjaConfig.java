package com.greninja.mod.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;
import java.io.*;
import java.nio.file.*;

public class GreninjaConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path CONFIG_PATH = FabricLoader.getInstance()
            .getConfigDir().resolve("greninja.json");
    private static GreninjaConfig INSTANCE = new GreninjaConfig();

    public boolean shieldIndicator     = true;
    public boolean armorHudEnabled     = true;
    public boolean fullbrightEnabled   = false;
    public boolean stutterFixEnabled   = true;
    public float   fullbrightIntensity = 15.0f;
    public int     armorHudX           = 2;
    public int     armorHudY           = -60;

    public static GreninjaConfig get() { return INSTANCE; }

    public static void load() {
        try {
            if (Files.exists(CONFIG_PATH)) {
                try (Reader r = Files.newBufferedReader(CONFIG_PATH)) {
                    GreninjaConfig loaded = GSON.fromJson(r, GreninjaConfig.class);
                    if (loaded != null) INSTANCE = loaded;
                }
            }
        } catch (Exception e) { INSTANCE = new GreninjaConfig(); }
    }

    public static void save() {
        try (Writer w = Files.newBufferedWriter(CONFIG_PATH)) {
            GSON.toJson(INSTANCE, w);
        } catch (Exception ignored) {}
    }
}
