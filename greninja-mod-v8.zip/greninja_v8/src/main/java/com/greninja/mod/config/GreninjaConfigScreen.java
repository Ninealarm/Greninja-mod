package com.greninja.mod.config;

import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

public class GreninjaConfigScreen extends Screen {
    private final Screen parent;

    public GreninjaConfigScreen(Screen parent) {
        super(Component.literal("Greninja Settings"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        int cx = this.width / 2;
        int bw = 220, bh = 20, gap = 24, y = 38;

        addToggle(cx, y,       bw, bh, "Shield Indicator",
            () -> GreninjaConfig.get().shieldIndicator,
            () -> { GreninjaConfig.get().shieldIndicator = !GreninjaConfig.get().shieldIndicator; });

        addToggle(cx, y+gap,   bw, bh, "Armor / Item Durability HUD",
            () -> GreninjaConfig.get().armorHudEnabled,
            () -> { GreninjaConfig.get().armorHudEnabled = !GreninjaConfig.get().armorHudEnabled; });

        addToggle(cx, y+gap*2, bw, bh, "Fullbright",
            () -> GreninjaConfig.get().fullbrightEnabled,
            () -> { GreninjaConfig.get().fullbrightEnabled = !GreninjaConfig.get().fullbrightEnabled; });

        addToggle(cx, y+gap*3, bw, bh, "Stutter Fix",
            () -> GreninjaConfig.get().stutterFixEnabled,
            () -> { GreninjaConfig.get().stutterFixEnabled = !GreninjaConfig.get().stutterFixEnabled; });

        // Fullbright intensity row
        int iy = y + gap * 4;
        this.addRenderableWidget(Button.builder(Component.literal(" - "),
            b -> { GreninjaConfig.get().fullbrightIntensity = Math.max(2f, GreninjaConfig.get().fullbrightIntensity - 1f);
                   GreninjaConfig.save(); rebuildWidgets(); })
            .bounds(cx - 110, iy, 30, bh).build());

        this.addRenderableWidget(Button.builder(
            Component.literal("Fullbright: " + (int)GreninjaConfig.get().fullbrightIntensity),
            b -> {}).bounds(cx - 75, iy, 150, bh).build());

        this.addRenderableWidget(Button.builder(Component.literal(" + "),
            b -> { GreninjaConfig.get().fullbrightIntensity = Math.min(100f, GreninjaConfig.get().fullbrightIntensity + 1f);
                   GreninjaConfig.save(); rebuildWidgets(); })
            .bounds(cx + 80, iy, 30, bh).build());

        this.addRenderableWidget(Button.builder(Component.literal("Done"),
            b -> this.minecraft.setScreen(parent))
            .bounds(cx - 50, this.height - 28, 100, 20).build());
    }

    private void addToggle(int cx, int y, int bw, int bh, String label,
                           java.util.function.BooleanSupplier getter, Runnable toggler) {
        this.addRenderableWidget(Button.builder(
            Component.literal(label + ": " + (getter.getAsBoolean() ? "ON" : "OFF")),
            b -> { toggler.run(); GreninjaConfig.save(); rebuildWidgets(); })
            .bounds(cx - bw/2, y, bw, bh).build());
    }

    @Override
    public void render(net.minecraft.client.gui.GuiGraphics g, int mx, int my, float delta) {
        this.renderBackground(g, mx, my, delta);
        g.drawCenteredString(this.font, this.title, this.width/2, 18, 0xFFFFAA00);
        super.render(g, mx, my, delta);
    }

    @Override
    public boolean isPauseScreen() { return false; }
}
